using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedOverTime : MonoBehaviour
{
    //public logicScript logic;
    //public pipeScript pipe;
    //private bool score = true;
    // Start is called before the first frame update
    void Start()
    {
        //logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<logicScript>();
        //pipe = GameObject.FindGameObjectWithTag("Pipe").GetComponent<pipeScript>();
    }

    // Update is called once per frame
    void Update()
    {
        //if ((logic.playerScore % 2 == 0) && (logic.playerScore != 0) && score) {
            //pipe.getSpeed();
            //moveSpeedIncrease();
        //}
    }

    //private void moveSpeedIncrease() {
        //pipe.increaseSpeed();
        //score = false;
        //if (logic.playerScore % 3 == 0) {
            //score = true;
        //}
    //}
}
