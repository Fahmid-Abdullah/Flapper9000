using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class logicScript : MonoBehaviour
{
    public int playerScore;
    public Text scoreText;
    public GameObject gameOverScreen;
    public GameObject bird;
    private bool birdStatus = true;
    public AudioSource source;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && birdStatus == false) {
            restartGame(birdStatus);
        }
        source = GetComponent<AudioSource>();

    }
    
    
    [ContextMenu("Plus One")]
    public void addScore(int scoreToAdd) {
        playerScore = playerScore + scoreToAdd;
        scoreText.text = playerScore.ToString();
    } 

    public void restartGame() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
         }

    public void restartGame(bool birdStatus) {
        if (birdStatus == false) {
           SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        } }

    public void gameOver() {
        gameOverScreen.SetActive(true);
        Destroy(bird);
        birdStatus = false;
        source.Play();
    }
 
}
