using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class middleScript : MonoBehaviour
{
    
    public logicScript logic;
    private AudioSource source;
    
    // Start is called before the first frame update
    void Start()
    {
        /* Since we cannot add this script to the pipes themselves as they are not there at the start of the game, this looks for the first instance of a an object with tag Logic */
        logic = GameObject.FindGameObjectWithTag("Logic").GetComponent<logicScript>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.layer == 3) {
            source.Play();
            logic.addScore(1);
        }
        
    }
}
